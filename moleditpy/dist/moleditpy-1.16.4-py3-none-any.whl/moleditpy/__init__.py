"""Top-level package for moleditpy.

"""

